#include <SoftwareSerial.h>
#include <Servo.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// CNC Shield V3 / Arduino UNO pin mapping
const uint8_t X_STEP_PIN = 2;
const uint8_t Y_STEP_PIN = 3;
const uint8_t X_DIR_PIN  = 5;
const uint8_t Y_DIR_PIN  = 6;
const uint8_t ENABLE_PIN = 8;

// HC-05: module TX -> A0, module RX <- A1 through a level shifter/divider
const uint8_t BT_RX_PIN = A0;
const uint8_t BT_TX_PIN = A1;

// SG90 signal. Confirm this pin is free on your exact shield/wiring.
const uint8_t SERVO_PIN = A3;

SoftwareSerial BT(BT_RX_PIN, BT_TX_PIN);
Servo penServo;

// CALIBRATE THESE for your mechanics. Example values are not universal.
float STEPS_PER_MM_X = 80.0f;
float STEPS_PER_MM_Y = 80.0f;
float currentX = 0.0f, currentY = 0.0f;
float feedRate = 600.0f; // mm/min
const float MAX_FEED_MM_MIN = 1200.0f;

int PEN_UP_ANGLE = 90;
int PEN_DOWN_ANGLE = 45;

char lineBuf[120];
uint8_t lineLen = 0;
bool absoluteMode = true;
bool mmMode = true;
volatile bool stopRequested = false;
bool paused = false;

void reply(const char *s) { BT.println(s); }

void pollControl() {
  while (BT.available()) {
    char c = (char)BT.read();
    if (c == '!') paused = true;
    else if (c == '~') paused = false;
    else if (c == '#') { stopRequested = true; paused = false; }
    // Ignore other bytes during an active move; file sender waits for "ok".
  }
}

bool waitWhilePaused() {
  while (paused && !stopRequested) {
    pollControl();
    delay(5);
  }
  return !stopRequested;
}

void penUp() { penServo.write(PEN_UP_ANGLE); delay(350); }
void penDown() { penServo.write(PEN_DOWN_ANGLE); delay(350); }

void stepPulse(uint8_t pin) {
  digitalWrite(pin, HIGH);
  delayMicroseconds(4);
  digitalWrite(pin, LOW);
}

bool moveLinear(float targetX, float targetY, float f) {
  if (!mmMode) { targetX *= 25.4f; targetY *= 25.4f; }
  if (!absoluteMode) { targetX += currentX; targetY += currentY; }

  long xTarget = lroundf(targetX * STEPS_PER_MM_X);
  long yTarget = lroundf(targetY * STEPS_PER_MM_Y);
  long xNow = lroundf(currentX * STEPS_PER_MM_X);
  long yNow = lroundf(currentY * STEPS_PER_MM_Y);
  long dx = labs(xTarget - xNow), dy = labs(yTarget - yNow);
  long sx = (xTarget >= xNow) ? 1 : -1;
  long sy = (yTarget >= yNow) ? 1 : -1;
  long err = dx - dy;
  long total = (dx > dy) ? dx : dy;
  if (total == 0) { currentX = targetX; currentY = targetY; return true; }

  digitalWrite(X_DIR_PIN, (xTarget >= xNow) ? HIGH : LOW);
  digitalWrite(Y_DIR_PIN, (yTarget >= yNow) ? HIGH : LOW);

  f = constrain(f, 30.0f, MAX_FEED_MM_MIN);
  float distance = sqrtf((targetX-currentX)*(targetX-currentX) +
                         (targetY-currentY)*(targetY-currentY));
  float seconds = (distance > 0.0001f) ? distance / (f / 60.0f) : 0.001f;
  unsigned long intervalUs = (unsigned long)constrain((seconds * 1000000.0f) / total, 80.0f, 20000.0f);

  long x = xNow, y = yNow;
  for (long i = 0; i < total; i++) {
    pollControl();
    if (!waitWhilePaused()) return false;
    if (stopRequested) return false;

    long e2 = 2 * err;
    if (e2 > -dy) { err -= dy; x += sx; stepPulse(X_STEP_PIN); }
    if (e2 < dx)  { err += dx; y += sy; stepPulse(Y_STEP_PIN); }

    unsigned long start = micros();
    while ((unsigned long)(micros() - start) < intervalUs) {
      pollControl();
      if (stopRequested) return false;
      if (paused) break;
    }
  }
  currentX = targetX;
  currentY = targetY;
  return true;
}

float getWord(char *s, char letter, float fallback) {
  for (uint8_t i=0; s[i]; i++) {
    if (toupper(s[i]) == letter) {
      char *endp;
      float v = strtof(s+i+1, &endp);
      if (endp != s+i+1) return v;
    }
  }
  return fallback;
}

void stripComments(char *s) {
  bool paren = false;
  uint8_t w = 0;
  for (uint8_t r=0; s[r]; r++) {
    if (s[r] == '(') { paren = true; continue; }
    if (s[r] == ')') { paren = false; continue; }
    if (paren || s[r] == ';') break;
    s[w++] = s[r];
  }
  s[w] = '\0';
}

void executeLine(char *s) {
  stripComments(s);
  while (*s == ' ' || *s == '\t') s++;
  if (!*s) { reply("ok"); return; }

  if (strstr(s, "G21") || strstr(s, "g21")) mmMode = true;
  if (strstr(s, "G20") || strstr(s, "g20")) mmMode = false;
  if (strstr(s, "G90") || strstr(s, "g90")) absoluteMode = true;
  if (strstr(s, "G91") || strstr(s, "g91")) absoluteMode = false;

  if (strstr(s, "M3") || strstr(s, "m3")) { penDown(); reply("ok"); return; }
  if (strstr(s, "M5") || strstr(s, "m5")) { penUp(); reply("ok"); return; }

  if (strstr(s, "G92") || strstr(s, "g92")) {
    currentX = getWord(s, 'X', 0.0f);
    currentY = getWord(s, 'Y', 0.0f);
    reply("ok"); return;
  }

  if (strstr(s, "G0") || strstr(s, "g0") || strstr(s, "G1") || strstr(s, "g1")) {
    float tx = getWord(s, 'X', currentX);
    float ty = getWord(s, 'Y', currentY);
    feedRate = getWord(s, 'F', feedRate);
    if (!moveLinear(tx, ty, feedRate)) {
      reply("stopped");
      stopRequested = false;
      return;
    }
  }
  reply("ok");
}

void setup() {
  pinMode(X_STEP_PIN, OUTPUT); pinMode(Y_STEP_PIN, OUTPUT);
  pinMode(X_DIR_PIN, OUTPUT); pinMode(Y_DIR_PIN, OUTPUT);
  pinMode(ENABLE_PIN, OUTPUT);
  digitalWrite(ENABLE_PIN, LOW); // A4988 enable is active-low
  penServo.attach(SERVO_PIN);
  penUp();

  Serial.begin(9600);
  BT.begin(9600);
  delay(300);
  reply("READY SWSM-P4");
}

void loop() {
  pollControl();
  if (stopRequested) {
    penUp();
    lineLen = 0;
    reply("stopped");
    stopRequested = false;
  }

  while (BT.available()) {
    char c = (char)BT.read();
    if (c == '\r') continue;
    if (c == '\n') {
      lineBuf[lineLen] = '\0';
      executeLine(lineBuf);
      lineLen = 0;
    } else if (lineLen < sizeof(lineBuf)-1) {
      lineBuf[lineLen++] = c;
    } else {
      lineLen = 0;
      reply("error:line-too-long");
    }
  }
}
