package com.smartwritingmachine.app;
import java.util.*;
public class PlotPath {
    public final List<float[]> points = new ArrayList<>();
    public void add(float x, float y) { points.add(new float[]{x,y}); }
}
