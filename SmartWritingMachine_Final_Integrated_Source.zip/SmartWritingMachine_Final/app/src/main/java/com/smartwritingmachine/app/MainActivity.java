package com.smartwritingmachine.app;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.*;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.UUID;

/**
 * Integrated Part 1-4 Android app.
 * Image and text jobs share one G-code buffer and one A4 preview.
 * Bluetooth uses Classic SPP (HC-05), one line at a time with firmware "ok" handshake.
 */
public class MainActivity extends Activity {
    private static final int PICK_IMAGE=10, SAVE_CODE=11, REQ_BT=12;
    private static final UUID SPP_UUID=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private final int navy=0xff14243a, blue=0xff315e9e;
    private boolean hindi=false, online=false, sending=false, waitingAck=false;
    private Bitmap selectedBitmap;
    private final ArrayList<PlotPath> paths=new ArrayList<>();
    private String gcode="";
    private EditText textInput, apiUrl;
    private Spinner imageMode, density, fontChoice, spacing, btDevices;
    private CheckBox fitText;
    private TextView status, imageInfo, codeInfo;
    private A4Preview preview;
    private BluetoothAdapter btAdapter;
    private BluetoothSocket btSocket;
    private InputStream btIn;
    private OutputStream btOut;
    private final ArrayList<BluetoothDevice> paired=new ArrayList<>();
    private final ArrayList<String> codeLines=new ArrayList<>();
    private int nextLine=0;
    private final Handler main=new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle b){super.onCreate(b);btAdapter=BluetoothAdapter.getDefaultAdapter();buildUi();}

    private TextView label(String s,int size,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(navy);
        if(bold)t.setTypeface(null,1);t.setPadding(0,7,0,7);return t;
    }
    private Button button(String s){
        Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(-1);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));return b;
    }
    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(0xffeff4fa);
        LinearLayout header=new LinearLayout(this);header.setPadding(12,4,12,4);header.setBackgroundColor(navy);
        TextView brand=label("✎ Smart Writing Machine",19,true);brand.setTextColor(-1);
        header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        Button language=new Button(this);language.setText(hindi?"English":"हिंदी");
        language.setOnClickListener(v->{hindi=!hindi;buildUi();});header.addView(language);root.addView(header);
        ScrollView scroll=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(16,10,16,28);scroll.addView(box);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);

        box.addView(label(tr("PHOTO TO G-CODE","फोटो से G-CODE"),21,true));
        box.addView(label(tr("Create A4 pen paths from a photo: Outline or Shading.","फोटो से A4 पेन पाथ बनाएँ: Outline या Shading।"),14,false));
        Button pick=button(tr("Choose photo","फोटो चुनें"));box.addView(pick);
        pick.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");startActivityForResult(i,PICK_IMAGE);});
        imageInfo=label(tr("No photo selected","फोटो नहीं चुनी गई"),13,false);box.addView(imageInfo);
        RadioGroup processing=new RadioGroup(this);processing.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton off=new RadioButton(this);off.setText("Offline");off.setId(1);off.setChecked(true);
        RadioButton on=new RadioButton(this);on.setText("Online API");on.setId(2);processing.addView(off);processing.addView(on);box.addView(processing);
        apiUrl=new EditText(this);apiUrl.setSingleLine(true);apiUrl.setHint("Your own HTTPS image-conversion API URL");apiUrl.setVisibility(View.GONE);box.addView(apiUrl);
        processing.setOnCheckedChangeListener((g,id)->{online=id==2;apiUrl.setVisibility(online?View.VISIBLE:View.GONE);});
        imageMode=new Spinner(this);imageMode.setAdapter(adapter("Outline","Shading / hatching"));box.addView(imageMode);
        density=new Spinner(this);density.setAdapter(adapter("Light shading","Medium shading","Dense shading"));box.addView(density);
        Button imageGen=button(tr("Generate photo paths","फोटो पाथ बनाएँ"));box.addView(imageGen);imageGen.setOnClickListener(v->generateImage());

        box.addView(label(tr("TEXT TO G-CODE","टेक्स्ट से G-CODE"),21,true));
        box.addView(label(tr("Hindi and English Unicode text vectorization.","हिंदी और अंग्रेज़ी Unicode टेक्स्ट को vector में बदलें।"),14,false));
        textInput=new EditText(this);textInput.setGravity(Gravity.TOP);textInput.setMinLines(3);textInput.setTextSize(18);
        textInput.setHint("Hello! नमस्ते दुनिया");textInput.setBackgroundColor(-1);box.addView(textInput,new LinearLayout.LayoutParams(-1,-2));
        fontChoice=new Spinner(this);fontChoice.setAdapter(adapter("Handwriting (italic fallback)","Sans / Computer","Serif","Monospace"));box.addView(fontChoice);
        spacing=new Spinner(this);spacing.setAdapter(adapter("Normal line spacing","Wide line spacing","Extra wide line spacing"));box.addView(spacing);
        fitText=new CheckBox(this);fitText.setText(tr("Fit text inside A4","टेक्स्ट को A4 में फिट करें"));fitText.setChecked(true);box.addView(fitText);
        Button textGen=button(tr("Generate text paths","टेक्स्ट पाथ बनाएँ"));box.addView(textGen);textGen.setOnClickListener(v->generateText());

        box.addView(label(tr("A4 PREVIEW · 210 × 297 mm","A4 प्रीव्यू · 210 × 297 mm"),18,true));
        preview=new A4Preview(this);box.addView(preview,new LinearLayout.LayoutParams(-1,620));
        Button save=button(tr("Save current G-code file","मौजूदा G-code सेव करें"));box.addView(save);
        save.setOnClickListener(v->saveGcode());
        codeInfo=label("No G-code generated.",13,false);box.addView(codeInfo);

        box.addView(label(tr("BLUETOOTH MACHINE CONTROL","ब्लूटूथ मशीन कंट्रोल"),21,true));
        box.addView(label(tr("Pair HC-05 in Android Bluetooth settings before connecting.","कनेक्ट करने से पहले Android Settings में HC-05 pair करें।"),13,false));
        btDevices=new Spinner(this);box.addView(btDevices);
        Button refresh=button(tr("Refresh paired devices","Paired डिवाइस Refresh करें"));box.addView(refresh);refresh.setOnClickListener(v->loadPaired());
        Button connect=button(tr("Connect HC-05","HC-05 कनेक्ट करें"));box.addView(connect);connect.setOnClickListener(v->connectBluetooth());
        Button start=button(tr("START / SEND G-CODE","START / G-CODE भेजें"));box.addView(start);start.setOnClickListener(v->startSending());
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(0);
        Button pause=button("PAUSE");Button resume=button("RESUME");Button stop=button("STOP");
        controls.addView(pause,new LinearLayout.LayoutParams(0,-2,1));controls.addView(resume,new LinearLayout.LayoutParams(0,-2,1));controls.addView(stop,new LinearLayout.LayoutParams(0,-2,1));box.addView(controls);
        pause.setOnClickListener(v->sendControl('!'));resume.setOnClickListener(v->sendControl('~'));
        stop.setOnClickListener(v->{sending=false;waitingAck=false;sendControl('#');});
        status=label(tr("Ready. Generate a job, inspect the A4 preview, then connect your machine.","तैयार। G-code बनाएँ, A4 प्रीव्यू जाँचें, फिर मशीन कनेक्ट करें।"),13,false);box.addView(status);
        box.addView(label(tr("Safety: remove the pen for first tests. Confirm machine origin, travel limits, motor direction, steps/mm and servo angles. This firmware has no homing or limit-switch protection. Keep a physical power switch within reach.","सुरक्षा: पहली जाँच में पेन निकालें। मशीन का origin, travel limit, motor direction, steps/mm और servo angle जाँचें। Firmware में homing या limit-switch सुरक्षा नहीं है। बिजली बंद करने का स्विच पास रखें।"),13,false));
        askBluetoothPermission();
    }

    private ArrayAdapter<String> adapter(String... values){return new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,values);}
    private String tr(String en,String hi){return hindi?hi:en;}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

    private void generateImage(){
        if(selectedBitmap==null){toast(tr("Choose a photo first.","पहले फोटो चुनें।"));return;}
        status.setText(tr("Processing photo…","फोटो प्रोसेस हो रही है…"));
        final boolean useOnline=online;final String endpoint=apiUrl.getText().toString().trim();
        final String mode=imageMode.getSelectedItemPosition()==0?"outline":"shading";
        final int den=density.getSelectedItemPosition()==0?2:density.getSelectedItemPosition()==1?5:8;
        new Thread(()->{try{
            List<PlotPath> made=useOnline?OnlineEngine.convert(selectedBitmap,endpoint,mode):
                (mode.equals("outline")?ImageEngine.outline(selectedBitmap,35,2):ImageEngine.shading(selectedBitmap,den));
            String code=GCodeWriter.make(made,900);
            main.post(()->{paths.clear();paths.addAll(made);gcode=code;preview.setPaths(paths);codeLines.clear();codeInfo.setText("Photo job: "+paths.size()+" paths, "+gcode.length()+" chars");status.setText("Photo G-code ready. Inspect preview.");});
        }catch(Exception e){main.post(()->status.setText("Photo conversion failed: "+e.getMessage()));}}).start();
    }

    private void generateText(){
        try{
            String f=fontChoice.getSelectedItemPosition()==0?"Handwriting":fontChoice.getSelectedItemPosition()==2?"Serif":fontChoice.getSelectedItemPosition()==3?"Monospace":"Sans";
            float ls=spacing.getSelectedItemPosition()==0?1f:spacing.getSelectedItemPosition()==1?1.25f:1.5f;
            TextVectorizer.Result r=TextVectorizer.create(textInput.getText().toString(),f,2.6f,ls,fitText.isChecked());
            paths.clear();paths.addAll(r.paths);gcode=GCodeWriter.make(paths,900);preview.setPaths(paths);
            codeLines.clear();codeInfo.setText("Text job: "+paths.size()+" paths, "+gcode.length()+" chars");
            status.setText("Text G-code ready. "+r.note+" Inspect preview.");
        }catch(Exception e){toast(e.getMessage()==null?"Text conversion failed":e.getMessage());}
    }

    private void saveGcode(){
        if(gcode.isEmpty()){toast("Generate a photo or text job first.");return;}
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TITLE,"smart_writing_job.gcode");startActivityForResult(i,SAVE_CODE);
    }

    private void askBluetoothPermission(){
        if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);
        else loadPaired();
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_BT)loadPaired();}

    private void loadPaired(){
        try{
            if(btAdapter==null){status.setText("Bluetooth is not available on this phone.");return;}
            paired.clear();ArrayList<String> names=new ArrayList<>();
            for(BluetoothDevice d:btAdapter.getBondedDevices()){paired.add(d);names.add(d.getName()+"  "+d.getAddress());}
            if(names.isEmpty())names.add("No paired devices. Pair HC-05 in Settings.");
            btDevices.setAdapter(adapter(names.toArray(new String[0])));
            status.setText("Paired Bluetooth devices: "+paired.size());
        }catch(SecurityException e){status.setText("Grant Nearby devices permission.");}
    }

    private void connectBluetooth(){
        if(paired.isEmpty()||btDevices.getSelectedItemPosition()<0||btDevices.getSelectedItemPosition()>=paired.size()){
            toast("Pair and select HC-05 first.");return;
        }
        final BluetoothDevice device=paired.get(btDevices.getSelectedItemPosition());
        status.setText("Connecting to "+device.getName()+"…");
        new Thread(()->{try{
            BluetoothSocket s=device.createRfcommSocketToServiceRecord(SPP_UUID);
            btAdapter.cancelDiscovery();s.connect();btSocket=s;btIn=s.getInputStream();btOut=s.getOutputStream();
            main.post(()->status.setText("HC-05 connected. Firmware should report READY."));
            listenBluetooth();
        }catch(Exception e){main.post(()->status.setText("Bluetooth connect failed: "+e.getMessage()));}}).start();
    }

    private void listenBluetooth(){
        new Thread(()->{
            try{
                BufferedReader reader=new BufferedReader(new InputStreamReader(btIn,"US-ASCII"));String line;
                while((line=reader.readLine())!=null){final String msg=line.trim();main.post(()->{
                    status.setText("Machine: "+msg);
                    if(msg.equalsIgnoreCase("ok")){waitingAck=false;if(sending)sendNextLine();}
                    else if(msg.equalsIgnoreCase("stopped")){sending=false;waitingAck=false;}
                    else if(msg.startsWith("error")){sending=false;waitingAck=false;}
                });}
            }catch(Exception e){main.post(()->{sending=false;status.setText("Bluetooth connection closed.");});}
        }).start();
    }

    private void startSending(){
        if(btOut==null){toast("Connect HC-05 first.");return;}
        if(gcode.isEmpty()){toast("Generate G-code first.");return;}
        if(!sending&&nextLine>=codeLines.size()){nextLine=0;}
        if(codeLines.isEmpty()){for(String s:gcode.split("\\r?\\n"))if(!s.trim().isEmpty())codeLines.add(s.trim());}
        sending=true;waitingAck=false;sendNextLine();
    }
    private void sendNextLine(){
        if(!sending||waitingAck||btOut==null)return;
        if(nextLine>=codeLines.size()){sending=false;status.setText("G-code transfer complete.");return;}
        String line=codeLines.get(nextLine++);waitingAck=true;
        try{btOut.write((line+"\\n").getBytes("US-ASCII"));btOut.flush();}
        catch(Exception e){sending=false;waitingAck=false;status.setText("G-code send failed: "+e.getMessage());}
    }
    private void sendControl(char c){
        try{if(btOut!=null){btOut.write((byte)c);btOut.flush();if(c=='!')status.setText("Pause requested.");if(c=='~')status.setText("Resume requested.");}}
        catch(Exception e){status.setText("Control command failed: "+e.getMessage());}
    }

    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;
        try{
            if(req==PICK_IMAGE){
                Uri u=data.getData();try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
                try(InputStream in=getContentResolver().openInputStream(u)){selectedBitmap=BitmapFactory.decodeStream(in);}
                if(selectedBitmap==null)throw new IOException("Cannot decode selected image.");
                imageInfo.setText("Selected image: "+selectedBitmap.getWidth()+" × "+selectedBitmap.getHeight());
                paths.clear();gcode="";codeLines.clear();preview.setPaths(paths);codeInfo.setText("Generate G-code from this photo.");
            }else if(req==SAVE_CODE){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write(gcode.getBytes("UTF-8"));}
                toast("G-code saved.");
            }
        }catch(Exception e){toast(e.getMessage()==null?"File error":e.getMessage());}
    }
    @Override protected void onDestroy(){
        sending=false;try{if(btSocket!=null)btSocket.close();}catch(Exception ignored){}super.onDestroy();
    }
}
