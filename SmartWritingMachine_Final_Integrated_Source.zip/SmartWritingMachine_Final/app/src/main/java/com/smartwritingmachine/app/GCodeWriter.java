package com.smartwritingmachine.app;
import java.util.*;
import java.util.Locale;
public class GCodeWriter {
    public static String make(List<PlotPath> paths,float feed){
        StringBuilder s=new StringBuilder("; Smart Writing Machine A4 job\n; Origin must be manually set at lower-left machine corner\nG21\nG90\nG17\nM5\n");
        for(PlotPath p:paths){if(p.points.size()<2)continue;float[] a=p.points.get(0);
            s.append(String.format(Locale.US,"G0 X%.2f Y%.2f\nM3\n",a[0],ImageEngine.PAGE_H-a[1]));
            for(int i=1;i<p.points.size();i++){float[] q=p.points.get(i);s.append(String.format(Locale.US,"G1 X%.2f Y%.2f F%.0f\n",q[0],ImageEngine.PAGE_H-q[1],feed));}
            s.append("M5\n");
        }
        return s.append("G0 X0 Y0\nM5\n").toString();
    }
}
