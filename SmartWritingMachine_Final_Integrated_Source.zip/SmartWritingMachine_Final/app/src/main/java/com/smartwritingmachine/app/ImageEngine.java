package com.smartwritingmachine.app;
import android.graphics.Bitmap;
import android.graphics.Color;
import java.util.*;

/** Offline raster-to-plotter engine. Coordinates are A4 millimetres, origin at top-left. */
public class ImageEngine {
    public static final float PAGE_W=210f, PAGE_H=297f, MARGIN=8f;
    private static int gray(int c){return (int)(0.299*Color.red(c)+0.587*Color.green(c)+0.114*Color.blue(c));}
    public static Bitmap scaled(Bitmap src,int maxSide){
        float s=Math.min(1f,(float)maxSide/Math.max(src.getWidth(),src.getHeight()));
        return Bitmap.createScaledBitmap(src,Math.max(1,(int)(src.getWidth()*s)),Math.max(1,(int)(src.getHeight()*s)),true);
    }
    public static List<PlotPath> outline(Bitmap source,int threshold,int stride){
        Bitmap b=scaled(source,700); int w=b.getWidth(),h=b.getHeight(); int[][] g=new int[h][w];
        for(int y=0;y<h;y++)for(int x=0;x<w;x++)g[y][x]=gray(b.getPixel(x,y));
        boolean[][] edge=new boolean[h][w];
        for(int y=1;y<h-1;y++)for(int x=1;x<w-1;x++){
            int gx=-g[y-1][x-1]+g[y-1][x+1]-2*g[y][x-1]+2*g[y][x+1]-g[y+1][x-1]+g[y+1][x+1];
            int gy=-g[y-1][x-1]-2*g[y-1][x]-g[y-1][x+1]+g[y+1][x-1]+2*g[y+1][x]+g[y+1][x+1];
            edge[y][x]=Math.sqrt(gx*gx+gy*gy)>threshold*4.0;
        }
        float scale=Math.min((PAGE_W-2*MARGIN)/w,(PAGE_H-2*MARGIN)/h);
        float ox=(PAGE_W-w*scale)/2f,oy=(PAGE_H-h*scale)/2f; List<PlotPath> out=new ArrayList<>();
        for(int y=1;y<h-1;y+=Math.max(1,stride)){int x=1;while(x<w-1){
            while(x<w-1&&!edge[y][x])x++;int start=x;while(x<w-1&&edge[y][x])x++;
            if(x-start>=2){PlotPath p=new PlotPath();p.add(ox+start*scale,oy+y*scale);p.add(ox+(x-1)*scale,oy+y*scale);out.add(p);}
        }} return out;
    }
    public static List<PlotPath> shading(Bitmap source,int density){
        Bitmap b=scaled(source,600);int w=b.getWidth(),h=b.getHeight();int[][] g=new int[h][w];
        for(int y=0;y<h;y++)for(int x=0;x<w;x++)g[y][x]=gray(b.getPixel(x,y));
        float scale=Math.min((PAGE_W-2*MARGIN)/w,(PAGE_H-2*MARGIN)/h);
        float ox=(PAGE_W-w*scale)/2f,oy=(PAGE_H-h*scale)/2f;List<PlotPath> out=new ArrayList<>();
        int step=Math.max(3,15-density);
        for(int c=-h;c<w;c+=step){PlotPath current=null;for(int y=0;y<h;y+=2){int x=c+y;
            boolean dark=x>=0&&x<w&&g[y][x]<(int)(220-density*3.0);
            if(dark){if(current==null){current=new PlotPath();current.add(ox+x*scale,oy+y*scale);}else current.add(ox+x*scale,oy+y*scale);}
            else if(current!=null){if(current.points.size()>1)out.add(current);current=null;}
        }if(current!=null&&current.points.size()>1)out.add(current);}
        return out;
    }
}
