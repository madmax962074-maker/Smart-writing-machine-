package com.smartwritingmachine.app;
import android.content.Context;
import android.graphics.*;
import android.view.View;
import java.util.*;

public class A4Preview extends View {
    private List<PlotPath> paths = new ArrayList<>();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    public A4Preview(Context c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
    public void setPaths(List<PlotPath> p) { paths = p == null ? new ArrayList<>() : p; invalidate(); }
    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float pad=18f, scale=Math.min((getWidth()-2*pad)/210f,(getHeight()-2*pad)/297f);
        if (scale <= 0) return;
        float w=210f*scale, h=297f*scale, l=(getWidth()-w)/2f, t=(getHeight()-h)/2f;
        paint.setStyle(Paint.Style.FILL); paint.setColor(Color.WHITE); c.drawRect(l,t,l+w,t+h,paint);
        paint.setStyle(Paint.Style.STROKE); paint.setColor(Color.LTGRAY); paint.setStrokeWidth(1f); c.drawRect(l,t,l+w,t+h,paint);
        paint.setColor(0xff172333); paint.setStrokeWidth(0.8f);
        for (PlotPath pp : paths) {
            if (pp.points.size()<2) continue;
            Path path=new Path(); float[] a=pp.points.get(0); path.moveTo(l+a[0]*scale,t+a[1]*scale);
            for(int i=1;i<pp.points.size();i++){float[] q=pp.points.get(i);path.lineTo(l+q[0]*scale,t+q[1]*scale);}
            c.drawPath(path,paint);
        }
    }
}
