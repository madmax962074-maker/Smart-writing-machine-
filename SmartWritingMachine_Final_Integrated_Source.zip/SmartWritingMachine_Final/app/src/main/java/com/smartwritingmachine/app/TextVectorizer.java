package com.smartwritingmachine.app;

import android.graphics.*;
import java.util.*;

/**
 * Converts Android-rendered Unicode text outlines to polylines in A4 millimetres.
 * Android's text shaping handles Devanagari conjuncts/matras and Latin shaping.
 */
public class TextVectorizer {
    public static final float A4_W=210f, A4_H=297f, MARGIN=12f;
    public static class Result {
        public final List<PlotPath> paths = new ArrayList<>();
        public float fontSizePx;
        public String note="";
    }

    public static Result create(String text, String fontStyle, float requestedMm,
                                float lineSpacing, boolean fitToPage) {
        if(text==null || text.trim().isEmpty()) throw new IllegalArgumentException("Please enter text.");
        Result result=new Result();
        Typeface face;
        if("Handwriting".equals(fontStyle)) {
            // Built-in fallback: italic sans. A real handwritten font can be bundled in a later build.
            face=Typeface.create("sans-serif",Typeface.ITALIC);
            result.note="Handwriting fallback: Android italic sans-serif (not a true cursive handwriting font).";
        } else if("Serif".equals(fontStyle)) face=Typeface.create("serif",Typeface.NORMAL);
        else if("Monospace".equals(fontStyle)) face=Typeface.create("monospace",Typeface.NORMAL);
        else face=Typeface.create("sans-serif",Typeface.NORMAL);

        // Use a generously sized offscreen bitmap for text shaping and glyph path extraction.
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTypeface(face);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(100f);
        paint.setSubpixelText(true);

        float maxWidthPx=1600f;
        float baseline=120f;
        float lineHeight=135f;
        Path all=new Path();
        String[] paragraphs=text.replace("\r","").split("\n",-1);
        for(String para:paragraphs) {
            if(para.isEmpty()) { baseline+=lineHeight*lineSpacing; continue; }
            // Break at word boundaries where possible; Hindi text without spaces is broken by code point.
            List<String> lines=wrap(para,paint,maxWidthPx);
            for(String line:lines) {
                Path linePath=new Path();
                paint.getTextPath(line,0,line.length(),0,baseline,linePath);
                all.addPath(linePath);
                baseline+=lineHeight*lineSpacing;
            }
        }
        RectF bounds=new RectF();
        all.computeBounds(bounds,true);
        if(bounds.isEmpty()) throw new IllegalArgumentException("Text produced no vector outline. Try another font or text.");
        float availableW=A4_W-2*MARGIN, availableH=A4_H-2*MARGIN;
        float targetMm=requestedMm;
        float scale=targetMm/100f; // Paint text size 100 px maps to requested mm per 100 px.
        float drawnW=bounds.width()*scale, drawnH=bounds.height()*scale;
        if(fitToPage) {
            float fit=Math.min(availableW/Math.max(1,drawnW),availableH/Math.max(1,drawnH));
            scale*=Math.min(1f,fit);
        }
        drawnW=bounds.width()*scale; drawnH=bounds.height()*scale;
        float ox=(A4_W-drawnW)/2f-bounds.left*scale;
        float oy=MARGIN-bounds.top*scale;
        result.fontSizePx=100f*scale;

        // Path.approximate emits fraction,x,y triples. Sampling preserves curves as small segments.
        float[] approx=all.approximate(0.65f);
        PlotPath current=null;
        float prevX=Float.NaN, prevY=Float.NaN;
        for(int i=0;i+2<approx.length;i+=3) {
            float x=ox+approx[i+1]*scale, y=oy+approx[i+2]*scale;
            // approximate's fraction jumps at contour starts; split contours.
            boolean contourStart=(i==0)||(approx[i]-approx[i-3]>0.00001f && distance(prevX,prevY,x,y)>Math.max(1.5f,scale*3f));
            if(contourStart) {
                if(current!=null && current.points.size()>1) result.paths.add(current);
                current=new PlotPath(); current.add(clamp(x, MARGIN,A4_W-MARGIN),clamp(y,MARGIN,A4_H-MARGIN));
            } else if(current!=null) current.add(clamp(x,MARGIN,A4_W-MARGIN),clamp(y,MARGIN,A4_H-MARGIN));
            prevX=x; prevY=y;
        }
        if(current!=null && current.points.size()>1) result.paths.add(current);
        if(result.paths.isEmpty()) throw new IllegalArgumentException("Could not extract text paths.");
        return result;
    }
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private static float distance(float x1,float y1,float x2,float y2){
        if(Float.isNaN(x1)||Float.isNaN(y1))return Float.MAX_VALUE;
        float dx=x2-x1,dy=y2-y1;return (float)Math.sqrt(dx*dx+dy*dy);
    }
    private static List<String> wrap(String text, Paint p, float maxWidth) {
        List<String> out=new ArrayList<>();
        String[] words=text.split("\\s+");
        StringBuilder line=new StringBuilder();
        for(String word:words) {
            String candidate=line.length()==0?word:line+" "+word;
            if(p.measureText(candidate)<=maxWidth) line=new StringBuilder(candidate);
            else {
                if(line.length()>0){out.add(line.toString());line.setLength(0);}
                if(p.measureText(word)<=maxWidth) line.append(word);
                else {
                    // Split long unbroken words by Unicode code point to avoid breaking surrogate pairs.
                    StringBuilder chunk=new StringBuilder();
                    for(int off=0;off<word.length();) {
                        int cp=word.codePointAt(off); String unit=new String(Character.toChars(cp)); off+=Character.charCount(cp);
                        if(p.measureText(chunk.toString()+unit)>maxWidth && chunk.length()>0){out.add(chunk.toString());chunk.setLength(0);}
                        chunk.append(unit);
                    }
                    line.append(chunk);
                }
            }
        }
        if(line.length()>0)out.add(line.toString());
        return out;
    }
}
