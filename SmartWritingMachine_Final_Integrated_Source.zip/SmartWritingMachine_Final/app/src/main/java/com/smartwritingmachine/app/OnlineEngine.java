package com.smartwritingmachine.app;
import android.graphics.Bitmap;
import android.util.Base64;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
public class OnlineEngine {
    public static List<PlotPath> convert(Bitmap bitmap,String endpoint,String mode)throws Exception{
        if(endpoint==null||!endpoint.startsWith("https://"))throw new IllegalArgumentException("Online API requires your own HTTPS endpoint.");
        ByteArrayOutputStream bos=new ByteArrayOutputStream();bitmap.compress(Bitmap.CompressFormat.JPEG,85,bos);
        JSONObject body=new JSONObject();body.put("imageBase64",Base64.encodeToString(bos.toByteArray(),Base64.NO_WRAP));body.put("mode",mode);body.put("paper","A4");
        HttpURLConnection conn=(HttpURLConnection)new URL(endpoint).openConnection();conn.setRequestMethod("POST");conn.setConnectTimeout(15000);conn.setReadTimeout(30000);conn.setDoOutput(true);conn.setRequestProperty("Content-Type","application/json");
        try(OutputStream os=conn.getOutputStream()){os.write(body.toString().getBytes("UTF-8"));}
        int code=conn.getResponseCode();InputStream in=(code>=200&&code<300)?conn.getInputStream():conn.getErrorStream();
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);
        String response=new String(out.toByteArray(),"UTF-8");conn.disconnect();if(code<200||code>=300)throw new IOException("API error "+code+": "+response);
        JSONArray arr=new JSONObject(response).getJSONArray("paths");List<PlotPath> result=new ArrayList<>();
        for(int i=0;i<arr.length();i++){JSONArray pts=arr.getJSONArray(i);PlotPath p=new PlotPath();for(int j=0;j<pts.length();j++){JSONArray xy=pts.getJSONArray(j);float x=(float)xy.getDouble(0),y=(float)xy.getDouble(1);if(x<0||x>210||y<0||y>297)throw new IOException("API coordinates outside A4.");p.add(x,y);}if(p.points.size()>1)result.add(p);}
        return result;
    }
}
