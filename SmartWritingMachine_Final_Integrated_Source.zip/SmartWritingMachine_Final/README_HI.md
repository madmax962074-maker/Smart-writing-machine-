# Smart Writing Machine – Final Integrated Project (Parts 1–4)

यह एक संयुक्त Android Java project है जिसमें Part 1 का app shell, Part 2 photo-to-G-code, Part 3 Hindi/English text-to-G-code और Part 4 HC-05 Bluetooth machine control को एक project में रखा गया है।

## मुख्य सुविधाएँ
- Photo to G-code: Offline Outline और Shading
- Optional Online conversion API contract (आपका अपना HTTPS API जरूरी; कोई hosted/free API bundled नहीं)
- Hindi + English text vectorization, A4 preview
- Handwriting italic fallback, Sans, Serif, Monospace
- G-code save
- HC-05 paired-device connection, one-line `ok` handshake sender
- Start / Pause / Resume / Stop controls

## Android मोबाइल से मुफ्त APK बनाने का तरीका (GitHub Actions)

यह तरीका ZIP upload करने के लिए बनाया गया है, इसलिए Android फोन से folders अलग-अलग upload करने की जरूरत नहीं।

1. GitHub पर अकाउंट बनाएँ और `SmartWritingMachine` नाम का नया repository बनाएँ: https://github.com/
2. Repository में **Add file → Upload files** चुनें और `SmartWritingMachine_Final_Integrated_Source.zip` को root में upload करके Commit करें।
3. Repository में **Add file → Create new file** चुनें। File name बिल्कुल यह रखें: `.github/workflows/android.yml`
4. ZIP के अंदर `GITHUB_WORKFLOW_COPY.yml` में दिया पूरा workflow text उस नई file में paste करें और Commit करें। (यदि workflow file ZIP extract होने के बाद nested project में भी हो, GitHub उसे root workflow नहीं मानेगा; इसलिए root पर अलग बनाना जरूरी है।)
5. GitHub के **Actions** tab में `Build Smart Writing Machine APK` चुनें। `Run workflow` दबाएँ, यदि push से अपने-आप run न हुआ हो।
6. Build पूरा होने पर workflow run खोलें → **Artifacts** → `SmartWritingMachine-debug-apk` डाउनलोड करें।
7. Artifact ZIP extract करें। उसमें `app-debug.apk` होगा। APK install करने से पहले source और build को जाँचें; Android की install permission केवल अपने भरोसेमंद build के लिए दें।

Workflow YAML की copy `GITHUB_WORKFLOW_COPY.yml` में दी गई है।

## Android Studio route
Project root `SmartWritingMachine_Final/` को Android Studio में Open करें, Gradle sync करें, फिर Build > Build APK(s) चुनें। APK सामान्यतः `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।

## Hardware pin map (CNC Shield V3 / UNO)
- X STEP D2, X DIR D5
- Y STEP D3, Y DIR D6
- A4988 ENABLE D8 (active LOW)
- HC-05 TX -> A0 (SoftwareSerial RX)
- UNO A1 (SoftwareSerial TX) -> HC-05 RX through resistor divider/level shifter
- SG90 signal A3

HC-05 RX पर UNO का 5V TX सीधे न लगाएँ। Servo को उपयुक्त अलग 5V supply दें और GND common रखें। Wiring बदलने से पहले motor supply और USB हटाएँ। A4988 current limit motor/driver datasheet के अनुसार अनुभवी व्यक्ति से set करवाएँ।

## Firmware / commissioning
Firmware `firmware/SmartWritingMachine_Part4.ino` में है। Arduino IDE में UNO चुनकर upload करें। Default steps/mm केवल placeholder examples हैं; अपनी mechanics के अनुसार calibrate करें। Servo angles भी calibrate करें। Firmware `G21`, `G90`, `G0`, `G1`, `G92`, `M3`, `M5` समझता है। Bluetooth control bytes: `!` pause, `~` resume, `#` stop.

**महत्वपूर्ण सीमाएँ**
- यह starter project है; यहाँ compile, APK generation और physical machine test प्रमाणित नहीं हैं।
- Firmware में homing/limit switches/soft travel bounds नहीं हैं। मशीन को manually known origin पर रखें।
- पहली जाँच में pen हटाएँ, कम गति पर छोटे movement test करें, emergency power switch पास रखें।
- Text paths glyph outlines हैं, single-line handwriting strokes नहीं। Handwriting option italic fallback है। Devanagari rendering Android fonts पर निर्भर है।
- Online photo mode तभी चलेगा जब आप compatible HTTPS API host करें।
- HC-05 classic Bluetooth SPP है; Bluetooth LE device से यह implementation connect नहीं करेगा।
- Part 4 firmware में step timing basic है, acceleration planner नहीं; बहुत तेज feed पर missed steps हो सकते हैं।
